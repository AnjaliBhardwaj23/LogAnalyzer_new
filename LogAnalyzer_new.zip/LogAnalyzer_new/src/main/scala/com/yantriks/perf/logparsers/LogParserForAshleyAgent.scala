package com.yantriks.perf.logparsers

import java.text.SimpleDateFormat
import com.yantriks.perf.loganalyzer.{LogEntry, LogParser}

class LogParserForAshleyAgent extends LogParser {
  //2018-10-29 13:41:51,878:TIMER  :Default Executor-thread-3379: createDaySlotMap - Begin                                     [admin]: [ ]: YFS_Res_PoolImpl
  //2018-10-29 13:41:51,896:TIMER  :Default Executor-thread-3379: createDaySlotMap - End -  [18]                               [admin]: [ ]: YFS_Res_PoolImpl
  //2020-05-11 06:32:38,149:TIMER  :Thread-41_AFICreateOrderAsyncService_19_0: getSystemRules-1 - End -  [1]                                [system]: [6d9ad562-5eef-4804-9e53-363678470f14]:  [AFI_WHOLESALE]: YFSBaseRuleManager
  //2020-05-11 06:32:38,150:TIMER  :Thread-41_AFICreateOrderAsyncService_19_0: getSystemRules-1 - Begin                                     [system]: [6d9ad562-5eef-4804-9e53-363678470f14]:  [AFI_WHOLESALE]: YFSBaseRuleManager
  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS")
  val patt = """(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}):TIMER  :(.+?): (.+?) - (Begin|End).*\[system\]:.*:.*: (\w+).*""".r
  val patt1 = """(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}):TIMER  :(.+?): (.+?)::\$\$.* - (Begin|End).*\[system\]:.*:.*: (\w+).*""".r
  val patt2 = """(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}):TIMER  :(.+?): (.+?) :.* - (Begin|End).*\[system\]:.*:.*: (\w+).*""".r
  val patt3 = """(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}):TIMER  :(.+?): (.+?) - .*- (Begin|End).*\[system\]:.*:.*: (\w+).*""".r

  override def parse(linenum: Int, line: String): LogEntry = {
    if (line.contains("$$")){
      val patt1(sdate,tname,label,begend,caller) = line
      val date = sdf.parse(sdate)
      new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
    }else if (line.contains("Executing on EntityDBHome, Fetching from Database")){
      val patt2(sdate,tname,label,begend,caller) = line
      val date = sdf.parse(sdate)
      new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
    }else if (line.contains("setSchema -")){
      val patt3(sdate,tname,label,begend,caller) = line
      val date = sdf.parse(sdate)
      new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
    }else{
      val patt(sdate,tname,label,begend,caller) = line
      val date = sdf.parse(sdate)
      new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
    }
    //val patt(sdate,tname,label,begend,caller) = line
//    val date = sdf.parse(sdate)
//    new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
  }

}
