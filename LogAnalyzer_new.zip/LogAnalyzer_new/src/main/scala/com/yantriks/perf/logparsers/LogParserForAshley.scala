package com.yantriks.perf.logparsers

import java.text.SimpleDateFormat

import com.yantriks.perf.loganalyzer.{LogEntry, LogParser}


class LogParserForAshley extends LogParser {

  //2018-10-29 13:41:51,878:TIMER  :Default Executor-thread-3379: createDaySlotMap - Begin                                     [admin]: [ ]: YFS_Res_PoolImpl

  //2018-10-29 13:41:51,896:TIMER  :Default Executor-thread-3379: createDaySlotMap - End -  [18]                               [admin]: [ ]: YFS_Res_PoolImpl

  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS")
  //val patt = """(\[\d{2}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}:\d{3} GMT\] \w+ \w+.*O )(.+?):TIMER  :(.+?): (.+?) - (Begin|End).+?: (\w+).*""".r
 // val patt = """(\[\d\/\d\/\d\d \d:\d\d:\d\d:\d\d\d GMT\] .+? SystemOut                                                    .+? )(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d,\d\d\d):TIMER  :(.+? .+?): (.+?) - (Begin|End).+? (\w+).*""".r
  val patt = """(\[\d\/\d\/\d\d \d{2}:\d\d:\d\d:\d\d\d GMT\] .+? SystemOut                                                    .+? )(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d,\d\d\d):TIMER  :(.+? .+?): (.+?) - (Begin|End).+? (\w+).*""".r
  override def parse(linenum: Int, line: String): LogEntry = {

    val patt(discard, sdate, tn, label, begend, caller) = line
    val date = sdf.parse(sdate)
    new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
  }


}
