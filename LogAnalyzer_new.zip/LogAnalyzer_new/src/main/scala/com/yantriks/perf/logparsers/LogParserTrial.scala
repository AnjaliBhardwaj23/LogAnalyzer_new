package com.yantriks.perf.logparsers

import java.text.SimpleDateFormat

import com.yantriks.perf.loganalyzer.{LogEntry, LogParser}



object LogParserTrial extends LogParser {

  def main(args: Array[String]): Unit = {
    //val line = """2020-05-11 06:32:38,147:TIMER  :Thread-41_AFICreateOrderAsyncService_19_0: getSystemRules-1 - End -  [2]                                [system]: [6d9ad562-5eef-4804-9e53-363678470f14]:  [AFI_WHOLESALE]: YFSBaseRuleManager        (of class java.lang.String)"""
    val line = """2020-06-10 06:15:46,855:TIMER  :Thread-39_AFILoadPlannedMOSubService: getListOfAdjustments - End -  [10575]                        [system]: [ae46171a-aa15-46c5-ad1a-e9289fba6a03]:  [ ]: YFSAdjustInventoryManagerImpl"""
    parse(1, line)
  }

  //2018-10-29 13:41:51,878:TIMER  :Default Executor-thread-3379: createDaySlotMap - Begin                                     [admin]: [ ]: YFS_Res_PoolImpl

  //2018-10-29 13:41:51,896:TIMER  :Default Executor-thread-3379: createDaySlotMap - End -  [18]                               [admin]: [ ]: YFS_Res_PoolImpl

  //2020-05-11 06:34:45,612:TIMER  :Thread-41_AFICreateOrderAsyncService_19_0: YCPContext - End -  [1]                                      [system]: [6d9ad562-5eef-4804-9e53-363678470f14]:  [AFI_WHOLESALE]: YCPContext

  //2020-05-11 06:32:38,147:TIMER  :Thread-41_AFICreateOrderAsyncService_19_0: getSystemRules-1 - End -  [2]                                [system]: [6d9ad562-5eef-4804-9e53-363678470f14]:  [AFI_WHOLESALE]: YFSBaseRuleManager        (of class java.lang.String)

  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS")
  val patt = """(\[\d{2}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}:\d{3} GMT\] \w+ \w+.*O )(.+?):TIMER  :(.+?): (.+?) - (Begin|End).+?: (\w+).*""".r

  /* override def parse(linenum: Int, line: String): LogEntry = {
       val patt(discard, sdate, tn, label, begend, caller) = line
       val date = sdf.parse(sdate)
       new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)
   }*/
  override def parse(linenum: Int, line: String): LogEntry = {
    //if (line.contains("$") || line.contains("$$End")) {
    val patt = """(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}):TIMER  :(.+?): (.+?) - (Begin|End).*\[system\]:.*:.*: (\w+).*""".r
      val patt(sdate, tn, label, begend, caller) = line
      val date = sdf.parse(sdate)
      System.out.println("Date: "+date+"Thread: "+tn+"Label: "+label+"Type: "+begend+"Method Name: "+caller);
      new LogEntry(linenum, line, date, "TIMER", "container", "thrnum", label, begend, caller)

  }
}


