# LogAnalyzer_new

Add /jars/timerloganalyzer_2.12-1.0.jar to Module setting of project (Right Click the project --> Open Module Setting --> Modules --> add timerloganalyzer_2.12-1.0.jar)
