timerlogstart_joann.bat ./messages.log "Default Executor-thread-159488" ""

Work if u have class file present for the code
for both types: bat and shell

For building the class for new project or any change in existing .scala,,use LogAnalyzer_new one

this is only testes for lulu and joaan and files are working
